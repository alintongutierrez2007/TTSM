<?php


if(!defined("ESPECIALCONSTANT"))die("Nuestros robots han denegado tu Acceso");


	
	function getConnection()
	{
		
		try{
		   $db_username="root";
		   $db_password="rqoperator";
		  $connection= new PDO("mysql:host=localhost;dbname=db_ttms", $db_username,$db_password);
		  $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

          		
			
		}
		catch(PDOException $e){
			
			echo "Error".$e->getMessage();
		}
		
		return $connection;
		

		
		
	}
	
	
	 ?>