<?php

require_once 'vendor/autoload.php';
require'Slim/Slim.php';

\Slim\Slim::registerAutoloader();
 
$app = new \Slim\Slim();
define("ESPECIALCONSTANT",true);
require 'libs/connect.php';
require'routes/Api.php';


 $app->contentType('text/html; charset=utf-8');

$app->get('/', function() {
           
			echo'<br><img src="http://191.98.228.86/logosgen/logodisatel.jpg"  WIDTH="250" HEIGHT="100">';
			echo "<br><br>API- Powered By Disatel Nicaragua";
        }); 



$app->run();




