<?php
date_default_timezone_set('America/Managua');
if(!defined("ESPECIALCONSTANT"))die("Nuestros robots han denegado tu Acceso");

include("lib_comun.php");



  //metodo de login
   	$app->post("/login/", function() use($app)
	{
		date_default_timezone_set('America/Managua');
		 $resultados = array();
         $resultados["hora"] = date("F j, Y, g:i a"); 
         $resultados["generador"] = "TTMS" ;

         $usuario = $app->request->post("usuario");
         $password = $app->request->post("password");

         $contador=0;
         $id_usuario='';
         $correo='';
         $direccion='';

         $connection=getConnection();

           try {

                 $datos = $connection->query("SELECT id,correo,direccion FROM usuarios_fn where usr='".$usuario."' and  pwd='".$password."' and activo='1' ");
                 foreach($datos as $row){
                   $id_usuario=$row[0];
                   $correo=$row[1];
                   $direccion=$row[2];
                 }
                    
             } catch(PDOException $e) {echo 'Error conectando con la base de datos, login: ' . $e->getMessage();}





           if($id_usuario!==''){
	           /*esta informacion se envia solo si la validacion es correcta */
	           $resultados["mensaje"] = "Validacion Correcta";
	            $resultados["validacion"] = "ok";
	            $resultados["id"] = $id_usuario;
              $resultados["correo"]=$correo;
               $resultados["direccion"]=$direccion;
          }else{
	         /*esta informacion se envia si la validacion falla */
	          $resultados["mensaje"] = "Usuario y password incorrectos";
	          $resultados["validacion"] = "error";
	          $resultados["id"] = "";
            $resultados["correo"]="";
             $resultados["direccion"]="";
          }

          // $resultados["query"] ="SELECT count(*) FROM usuarios_fn where usr='".$usuario."' and  pwd='".$password."' and activo='1'";



          $app->response->headers->set("Content-type","application/json");
	      $app->response->status(200);
	      $app->response->body(json_encode($resultados));    

	});




   	$app->post("/listarRutas/", function() use ($app)
	{
	
	  $arreglo=array();

      try{
	      $connection=getConnection();


         $sql=$connection->prepare("SELECT id,nombre_ruta,detalle_ruta,tipo_ruta from rutas where activo_ruta='1'");
         $sql->execute();
         $resultado=$sql->fetchAll();

             foreach($resultado as $row){
	                $arreglo[] = array('idruta'=>$row['id'],'nombre_ruta'=>utf8_encode($row['nombre_ruta']), 
          	       'detalle_ruta'=>utf8_encode($row['detalle_ruta']), 'tipo_ruta'=>$row['tipo_ruta']);
               }
	

         
         }catch(PDOException $e){ echo "Error".$e->getMessage();}  


	      $app->response->headers->set("Content-type","application/json");
	      $app->response->status(200);
	      $app->response->body(json_encode($arreglo));
        


       
	});



  $app->post("/listarPuntos/", function() use ($app)
  {
  
    $arreglo=array();

      try{
        $connection=getConnection();


         $sql=$connection->prepare("SELECT id,nombre_punto,id_ruta_punto from puntos where estado_punto='1'");
         $sql->execute();
         $resultado=$sql->fetchAll();

             foreach($resultado as $row){
                  $arreglo[] = array('idpunto'=>$row['id'],'nombre_punto'=>utf8_encode($row['nombre_punto']), 
                 'id_ruta_punto'=>$row['id_ruta_punto']);
               }
  

         
         }catch(PDOException $e){ echo "Error".$e->getMessage();}  


        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($arreglo));
        


       
  });










  //metodo de insertar solicitudes usando post
	
	$app->post("/registrarSolicitud/", function() use($app)
	{
	   
	   date_default_timezone_set('America/Managua');

	   $ayer= date('Y-m-d', strtotime('-1 day')); 
	   $estado=array();

       $id_usuario=$app->request->post("id_usuario");
       $id_ruta=$app->request->post("id_ruta");
       $fecha=$app->request->post("fecha");
       $fecha_desde=$app->request->post("fecha_desde");
       $fecha_hasta=$app->request->post("fecha_hasta");	
       $tipo=$app->request->post("tipo");
       $frecuencia=$app->request->post("frecuencia");

       //nuevos datos para correo
       $correo=$app->request->post("correo");
       $usuario=$app->request->post("nombre_usr");
       $ruta=$app->request->post("nombre_ruta");
       $detalle_ruta=$app->request->post("detalle_ruta");

       //campos para para operacion domiciliar
       $id_punto=$app->request->post("id_punto");
       $direccion=$app->request->post("direccion");
 
        
       
        $hora_inicio_ruta='00:00:00';
        

        //verificamos si es posible insertar , por dia y fecha de insert
        try {
                 $connection=getConnection();
                 $datos = $connection->query("SELECT hora_inicio FROM rutas where id='".$id_ruta."'");
                 foreach($datos as $row){
                   $hora_inicio_ruta=$row[0];
                 }
                    
             } catch(PDOException $e) {echo 'Error conectando con la base de datos, login: ' . $e->getMessage();}

      
           
      
      

          //registro una vez  
	       if($frecuencia=="unavez"){

	       	if($fecha >$ayer){

              $fecha_hora=$fecha.' '.$hora_inicio_ruta;
              $fecha_dos=strtotime('-1 hour',strtotime($fecha_hora));
              $fecha_dos=date('Y-m-d H:i:s',$fecha_dos);
              $fecha_actual=date('Y-m-d H:i:s');

              if($fecha_actual < $fecha_dos){


                //verificamos duplicados
                $numero_registro=0;

                  try {
                       $connection=getConnection();
                       $datos = $connection->query("SELECT count(*) FROM solicitudes where id_usuario='".$id_usuario."'
                            and id_ruta='".$id_ruta."' and fecha='".$fecha."' and estado_servicio='1' ");
                      foreach($datos as $row){
                       $numero_registro=$row[0];
                      }
                    
                     } catch(PDOException $e) {echo 'Error conectando con la base de datos, login: ' . $e->getMessage();}


               if($numero_registro==0){



               try{
		 
	                $connection=getConnection();
                   $stmt = $connection->prepare('INSERT INTO solicitudes( fecha, id_usuario, id_ruta, tipo, id_punto, direccion) 
                  	VALUES (:fecha, :id_usuario, :id_ruta, :tipo, :id_punto, :direccion)');

                   $rows=$stmt->execute(array(':fecha'=>$fecha ,':id_usuario' =>$id_usuario,
                 	  ':id_ruta'=>$id_ruta, ':tipo'=>$tipo, ':id_punto'=>$id_punto, ':direccion'=>$direccion));

             
                    if($rows==1){
                 	      $estado[]="Solicitud registrada";

                       //notificar por correo
                       NotificarSolicitud($correo,$usuario,$ruta,$fecha,$detalle_ruta);

                      }else{
                       $estado[]="Error sql";
                       }

                      
                
	                   }catch(PDOException $e){echo "Error insertando".$e->getMessage();}

               }else{

                   $estado[]="Error: registro duplicado";

               }


                  }else{
                    $estado[]="Error: debes solicilitar transporte 2 hrs antes en dia actual".$fecha_dos;

                 }

	         }else{
                $estado[]="Error en campo fecha";
	         }

     
	        }






	         if($frecuencia=="varias"){




             if(($fecha_desde<$fecha_hasta)&&($fecha_desde >$ayer)){


                   $fecha_hora=$fecha_desde.' '.$hora_inicio_ruta;
                   $fecha_dos=strtotime('-1 hour',strtotime($fecha_hora));
                   $fecha_dos=date('Y-m-d H:i:s',$fecha_dos);
                   $fecha_actual=date('Y-m-d H:i:s');


                   $arreglo_dias=array(); 	
                   $arreglo_dias[]=$fecha_desde;



              if($fecha_actual < $fecha_dos){


                   
                 if($fecha_desde < $fecha_hasta){
	                  $fecha_dinamica=$fecha_desde;
	                  while($fecha_dinamica!=$fecha_hasta){
		                 $fecha_dinamica=date('Y-m-d', strtotime($fecha_dinamica.'+1 day'));
		                 $arreglo_dias[]=$fecha_dinamica;
	                 }
                   }


                  if($fecha_desde==$fecha_hasta){
                     $arreglo_dias[]=$fecha_desde;	
                    }



                        //verificamos duplicados
                      $numero_registro=0;

                      try {
                           $connection=getConnection();
                        $datos = $connection->query("SELECT count(*) FROM solicitudes where id_usuario='".$id_usuario."'
                             and id_ruta='".$id_ruta."' and fecha between '".$fecha_desde."' and '".$fecha_hasta."'
                             and estado_servicio='1' ");
                      foreach($datos as $row){
                       $numero_registro=$row[0];
                      }
                    
                     } catch(PDOException $e) {echo 'Error conectando con la base de datos, login: ' . $e->getMessage();}



                     $bandera_insert=false;


                     if($numero_registro<1){


                     if(count($arreglo_dias)<16){
                     

                    foreach($arreglo_dias as $fecha){

                         try{
		 
	                       $connection=getConnection();
                           $stmt = $connection->prepare('INSERT INTO solicitudes( fecha, id_usuario, id_ruta, tipo,id_punto,direccion) 
                  	        VALUES (:fecha, :id_usuario, :id_ruta, :tipo, :id_punto, :direccion)');

                          $rows=$stmt->execute(array(':fecha'=>$fecha ,':id_usuario' =>$id_usuario,
                 	        ':id_ruta'=>$id_ruta, ':tipo'=>$tipo, ':id_punto'=> $id_punto, ':direccion'=>$direccion));
             
                           if($rows==1){
                 	           $estado[]="Solicitud registrada";

                            $bandera_insert=true;

                              }else{
                                $estado[]="Error sql";
                              }
                
	                        }catch(PDOException $e){echo "Error insertando".$e->getMessage();}

                      }//fin de foreach de fechas



                    }else{

                      $estado[]="Error: no se permite mas de 15 dias";
                    }
                 
                     }else{
                         $estado[]="Error: registro duplicado";
                     }


                   }else{
                     $estado[]="Error: debes solicilitar transporte 2 hrs antes en dia actual";

                    }





                          if($bandera_insert==true){

                            //notificar por correo
                             $textfecha='desde:'.$fecha_desde.', hasta:'.$fecha_hasta;
                             NotificarSolicitud($correo,$usuario,$ruta,$textfecha,$detalle_ruta);

                          }
	        	               



             }else{

             	$estado[]="Error fecha incorrecta";
             }


            }//fin de varias fechas


       
        $app->response->headers->set("Content-type","application/json");
	      $app->response->status(200);
	      $app->response->body(json_encode($estado)); 

	 	
	 	
	});
	
	     

	   	 
	
	
	 // metodo ver todos los registros de solcitudes

$app->post("/listaSolicitudes_ida/", function() use ($app)
	{
        date_default_timezone_set('America/Managua');
        $arreglo_historico=array();
         $id_usuario=$app->request->post("id_usuario");

            $hoy= date('Y-m-d'); 
            $diacinco= date('Y-m-d', strtotime('-5 day')); 
            $hora_actual=date('H:i:s');


	    try{
	          $connection=getConnection();
              $sql=$connection->prepare("SELECT solicitudes.id,nombre_ruta,fecha,tipo,fecha_creado,estado_pendiente,id_ruta,
              hora_inicio,hora_fin, id_punto, coalesce(nombre_punto,'vacio') as punto_nombre, direccion
              	from solicitudes
              	inner join rutas on rutas.id=solicitudes.id_ruta
                left join puntos on puntos.id=solicitudes.id_punto
              	where estado_servicio='1' and id_usuario='$id_usuario' and estado_pendiente='1' and tipo='1'
              	 order by fecha asc");
              $sql->execute();
              $resultado=$sql->fetchAll();

             foreach($resultado as $row){



                  $fecha_hora=$row['fecha'].' '.$row['hora_inicio'];

                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $fecha_actual=date('Y-m-d H:i:s');

                   if($fecha_actual < $fecha_cuatro){
                   // echo'<br> si puedes borrar';
                     $opcion_borrado=1;
                  }else{
                    //echo'<br> no puedes borrar';
                     $opcion_borrado=0;
                  }




             	     $pendiente=$row['estado_pendiente'];

                  if($pendiente==1){
                      $status='Agendado';
                  }else{
                    $status='Procesado';
                  }
                   

                   if($row['fecha']<date('Y-m-d')){
                      $status='Procesado';
                    }


                 if($status=='Agendado'){
                       $arreglo_historico[] = array('idhistorico'=>$row['id'],'nombre_ruta'=>$row['nombre_ruta'],
                        'fecha'=>$row['fecha'],'creado'=>$row['fecha_creado'],'tipo'=>$row['tipo'], 'id_ruta'=>$row['id_ruta'],
                        'estado_pendiente'=>$row['estado_pendiente'],'opcion_borrado'=>$opcion_borrado,'txstatus'=>$status,
                        'id_punto'=>$row['id_punto'],'nombre_punto'=>$row['punto_nombre'], 'direccion'=>$row['direccion']);
                  }
             }


          }catch(PDOException $e){ echo "Error".$e->getMessage();}


       $app->response->headers->set("Content-type","application/json");
	   $app->response->status(200);
	   $app->response->body(json_encode($arreglo_historico));

});
	
	

	

  
   // metodo ver todos los registros de solcitudes

$app->post("/listaSolicitudes_reg/", function() use ($app)
  {
        date_default_timezone_set('America/Managua');
        $arreglo_historico=array();
         $id_usuario=$app->request->post("id_usuario");

            $hoy= date('Y-m-d'); 
            $diacinco= date('Y-m-d', strtotime('-5 day')); 
            $hora_actual=date('H:i:s');


      try{
            $connection=getConnection();
              $sql=$connection->prepare("SELECT solicitudes.id,nombre_ruta,fecha,tipo,fecha_creado,estado_pendiente,id_ruta,
              hora_inicio,hora_fin,id_punto, coalesce(nombre_punto,'vacio') as punto_nombre, direccion 
                from solicitudes
                inner join rutas on rutas.id=solicitudes.id_ruta
                left join puntos on puntos.id=solicitudes.id_punto
                where estado_servicio='1' and id_usuario='$id_usuario' and estado_pendiente='1' and tipo='0'
                 order by fecha asc");
              $sql->execute();
              $resultado=$sql->fetchAll();

             foreach($resultado as $row){



                  $fecha_hora=$row['fecha'].' '.$row['hora_inicio'];

                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $fecha_actual=date('Y-m-d H:i:s');

                   if($fecha_actual < $fecha_cuatro){
                   // echo'<br> si puedes borrar';
                     $opcion_borrado=1;
                  }else{
                    //echo'<br> no puedes borrar';
                     $opcion_borrado=0;
                  }




                   $pendiente=$row['estado_pendiente'];

                  if($pendiente==1){
                      $status='Agendado';
                  }else{
                    $status='Procesado';
                  }
                   

                   if($row['fecha']<date('Y-m-d')){
                      $status='Procesado';
                    }


                 if($status=='Agendado'){
                       $arreglo_historico[] = array('idhistorico'=>$row['id'],'nombre_ruta'=>$row['nombre_ruta'],
                        'fecha'=>$row['fecha'],'creado'=>$row['fecha_creado'],'tipo'=>$row['tipo'],'id_ruta'=>$row['id_ruta'],
                        'estado_pendiente'=>$row['estado_pendiente'],'opcion_borrado'=>$opcion_borrado,'txstatus'=>$status,
                          'direccion'=>$row['direccion'], 'id_punto'=> $row['id_punto'], 'punto_nombre'=> $row['punto_nombre']);
                  }
             }


          }catch(PDOException $e){ echo "Error".$e->getMessage();}


       $app->response->headers->set("Content-type","application/json");
     $app->response->status(200);
     $app->response->body(json_encode($arreglo_historico));

});





  //metodo para editar estado de registro solcitudes
  
  $app->post("/EditarPeticion/", function() use($app)
  {

     date_default_timezone_set('America/Managua');
     
     $bandera_actualizado=false;
     
      $usuario=$app->request->post("usuario");
      $id_update=$app->request->post("id_update");
      $fecha_update=$app->request->post("fecha_update");
      $ruta_update=$app->request->post("ruta_update");

      $nombre_ruta=$app->request->post("nombre_ruta");
      $correo_enviar=$app->request->post("correo");

      $id_punto=$app->request->post("id_punto");
      $direccion=$app->request->post("direccion");

    
      $actualizar=0;
      $estado_update=array();
      $detalle='Actualizado por:'.$usuario.', a las:'.date('Y-m-d H:i:s');
      $fecha_solicitado='';
      $hora_inicio_ruta='';


      //selecionar el dia y hora, verificando que sea posible cancelar la peticion

         $connection=getConnection();

           try {

                 $datos = $connection->query("SELECT fecha, hora_inicio 
                  FROM solicitudes
                 inner join rutas on solicitudes.id_ruta=rutas.id
                  where solicitudes.id='".$id_update."'");
                 foreach($datos as $row){
                   $fecha_solicitado=$row[0];
                   $hora_inicio_ruta=$row[1];
                 }
                    
             } catch(PDOException $e) {echo 'Error conectando con la base de datos, update: ' . $e->getMessage();}




            if(($fecha_solicitado!="") && ($hora_inicio_ruta!='')){


                 $fecha_hora=$fecha_solicitado.' '.$hora_inicio_ruta;

                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $fecha_actual=date('Y-m-d H:i:s');

                   if($fecha_actual < $fecha_cuatro){
                   // echo'<br> si puedes borrar';
                     
                      
                  try{

                   $stmt = $connection->prepare("UPDATE solicitudes SET fecha=:fecha,id_ruta=:id_ruta, 
                    detalle=:detalle,  id_punto=:id_punto, direccion=:direccion
                    WHERE id=:id");
                   $rows = $stmt->execute( array(':fecha'=>$fecha_update,':id_ruta'=>$ruta_update,
                    ':detalle'=>$detalle,':id'=> $id_update, ':direccion'=>$direccion,':id_punto'=> $id_punto));
            
                    if( $rows > 0 ){
                       $estado_update[]='Peticion Actualizada';
                         $bandera_actualizado=true;
                    }

                     } catch(PDOException $e){echo "Error".$e->getMessage();} 

                     


                  }else{
                    //echo'<br> no puedes borrar';
                    $estado_update[]='Error ya no puedes Actualizar';
                    
                  }



                 

                 //si a sido actualizado. confirmaremos via correo

                  if(($bandera_actualizado==true)&&($correo_enviar!="")){


                   $CopiarA="alinton.gutierrez@grupodisatel.com";
                   $Asunto="Actualizacion de Abordaje Realizada";
                   $Cuerpo="<br><br><strong>Datos</strong>";
                   $Cuerpo="<br><strong>usuario:</strong>".$usuario;
                   $Cuerpo.="<br><strong>Ruta:</strong>".$nombre_ruta;
                   $Cuerpo.="<br><strong>Fecha:</strong>".$fecha_update;
                   $Cuerpo.="<br><strong>Generado a las:</strong>".date('Y-m-d H:i:s');
                   $Cuerpo.="<br><br>Gracias por utilizar nuestra Aplicacion.";
                   $Cuerpo.="<br>Powered by Disatel NI";

                   $Cuerpo.="<br><br>Aviso de confidencialidad:";
                   $Cuerpo.="<br><p> Este mensaje y sus documentos adjuntos, pueden contener informacion privilegiada y/o  
                   confidencial  que  esta dirigida  exclusivamente a su destinatario. Si usted recibe este mensaje y
                   no es el destinatario indicado,por favor, notifiquelo inmediatamente y remita el mensaje original 
                   al correo electronico indicado. Cualquier  copia,  uso  o  distribucion no autorizados de esta 
                   comunicacion queda estrictamente prohibida.</p>";
               
                    EnviaCorreo($correo_enviar,$CopiarA,$Asunto,$Cuerpo,true);



                 }





            }//fin si tiene datos validos
                  



        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($estado_update)); 


      });







			
	//metodo para editar estado de registro solcitudes
	
	$app->post("/cancelarPeticion/", function() use($app)
	{
       $bandera_actualizado=false;
		   date_default_timezone_set('America/Managua');

	   
	   $usuario=$app->request->post("usuario");
	   $id_historico=$app->request->post("id_historico");
     $correo_enviar=$app->request->post("correo");



	  
	    $desactivar=0;
	    $estado_update=array();
	    $detalle='cancelado por:'.$usuario.', a las:'.date('Y-m-d H:i:s');
      $fecha_solicitado='';
      $hora_inicio_ruta='';
      $nombre_ruta='';
      $detalle_ruta='';


      //selecionar el dia y hora, verificando que sea posible cancelar la peticion

         $connection=getConnection();

           try {

                 $datos = $connection->query("SELECT fecha, hora_inicio, nombre_ruta, detalle_ruta
                  FROM solicitudes
                 inner join rutas on solicitudes.id_ruta=rutas.id
                  where solicitudes.id='".$id_historico."'");
                 foreach($datos as $row){
                   $fecha_solicitado=$row[0];
                   $hora_inicio_ruta=$row[1];
                   $nombre_ruta=$row[2];
                   $detalle_ruta=$row[3];
          
                 }
                    
             } catch(PDOException $e) {echo 'Error conectando con la base de datos, login: ' . $e->getMessage();}




            if(($fecha_solicitado!="") && ($hora_inicio_ruta!='')){


                 $fecha_hora=$fecha_solicitado.' '.$hora_inicio_ruta;

                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $fecha_actual=date('Y-m-d H:i:s');

                   if($fecha_actual < $fecha_cuatro){
                   // echo'<br> si puedes borrar';
                     
                      
                  try{

                   $stmt = $connection->prepare("UPDATE solicitudes SET estado_servicio=:estado,detalle=:detalle WHERE id=:id");
                   $rows = $stmt->execute( array(':estado'=>$desactivar,':detalle'=>$detalle,':id'=>$id_historico));
            
                    if( $rows > 0 ){
                       $estado_update[]='Peticion Cancelada';
                       $bandera_actualizado=true;
                    }

                     } catch(PDOException $e){echo "Error".$e->getMessage();} 

                     


                  }else{
                    //echo'<br> no puedes borrar';
                    $estado_update[]='Error ya no puede eliminarla';
                    
                  }



                    //si a sido actualizado. confirmaremos via correo

                  if(($bandera_actualizado==true)&&($correo_enviar!="")){


                   $CopiarA="alinton.gutierrez@grupodisatel.com";
                   $Asunto="Cancelacion de Abordaje Realizada";
                   $Cuerpo="<br><br><strong>Datos</strong>";
                   $Cuerpo="<br><strong>usuario:</strong>".$usuario;
                   $Cuerpo.="<br><strong>Ruta Abordar:</strong>".$nombre_ruta;
                   $Cuerpo.="<br><strong>Detalle Ruta:</strong>".$detalle_ruta;
                   $Cuerpo.="<br><strong>Fecha Abordaje:</strong>".$fecha_solicitado;
                   $Cuerpo.="<br><strong>Generado a las:</strong>".date('Y-m-d H:i:s');
                   $Cuerpo.="<br><br>Gracias por utilizar nuestra Aplicacion.";
                   $Cuerpo.="<br>Powered by Disatel NI";

                   $Cuerpo.="<br><br>Aviso de confidencialidad:";
                   $Cuerpo.="<br><p> Este mensaje y sus documentos adjuntos, pueden contener informacion privilegiada y/o  
                   confidencial  que  esta dirigida  exclusivamente a su destinatario. Si usted recibe este mensaje y
                   no es el destinatario indicado,por favor, notifiquelo inmediatamente y remita el mensaje original 
                   al correo electronico indicado. Cualquier  copia,  uso  o  distribucion no autorizados de esta 
                   comunicacion queda estrictamente prohibida.</p>";
               
                    EnviaCorreo($correo_enviar,$CopiarA,$Asunto,$Cuerpo,true);



                 }

                   





            }//fin si tiene datos validos
                  



        $app->response->headers->set("Content-type","application/json");
	      $app->response->status(200);
	      $app->response->body(json_encode($estado_update)); 


      });
	
	
	


    
$app->post("/proximoAbordaje/", function() use ($app)
	{
        date_default_timezone_set('America/Managua');
        $ayer= date('Y-m-d', strtotime('-1 day')) ; 

        $arreglo_proxAbordaje=array();
         $id_usuario=$app->request->post("id_usuario");

            $hoy=date('Y-m-d'); 
            $hora_actual=date('H:i:s');
                $registros=0;

      try{
            $connection=getConnection();
              $sql=$connection->prepare("SELECT solicitudes.id,nombre_ruta,id_ruta,fecha,tipo,hora_inicio,
                 hora_fin, coalesce(nombre_punto,'vacio') as punto_nombre,direccion
                 from solicitudes
                 inner join rutas on rutas.id=solicitudes.id_ruta
                 left join puntos on puntos.id=solicitudes.id_punto
                 where estado_servicio='1' and id_usuario='$id_usuario' and estado_pendiente='1'
                 order by fecha,hora_inicio asc");
              $sql->execute();
              $resultado=$sql->fetchAll();

             foreach($resultado as $row){


             
                 $visualizable=0;

                if($row['fecha']>$ayer){
                      


                  $fecha_hora_hasta=$row['fecha'].' '.$row['hora_fin'];

                  $fecha_hora_hasta=strtotime('+20 minute',strtotime($fecha_hora_hasta));
                  $fecha_hora_hasta=date('Y-m-d H:i:s',$fecha_hora_hasta);



                  $fecha_hora=$row['fecha'].' '.$row['hora_inicio'];

                  $fecha_uno=strtotime('-1 hour',strtotime($fecha_hora));
                  $fecha_uno=date('Y-m-d H:i:s',$fecha_uno);


                  $fecha_actual=date('Y-m-d H:i:s');




                   if(($fecha_actual > $fecha_uno)&&($fecha_actual < $fecha_hora_hasta)){
                   // echo'<br> si puedes borrar';
                     $visualizable=1;
                    }else{
                     //echo'<br> no puedes borrar';
                      $visualizable=0;
                     }

                      $tipo='';

                     if($row['tipo']==1){
                          $tipo='Trasl. Aeropuerto';
                     }else if($row['tipo']==0){
                          $tipo='Transp. Domiliar';
                     }


                       if(($registros < 3)&&($row['tipo']!=3)){

                         $arreglo_proxAbordaje[] = array('id_solicitud'=>$row['id'],'nombre_ruta'=>$row['nombre_ruta'],
                            'id_ruta'=>$row['id_ruta'],'fecha'=>$row['fecha'],'tipo'=>$tipo, 
                           'hora_inicio'=>$row['hora_inicio'],'hora_fin'=>$row['hora_fin'],'visualizable'=>$visualizable,
                           'nombre_punto'=>$row['punto_nombre'], 'direccion'=>$row['direccion']);
                      
                            $registros++;

                       }
                      
                   
                    }

                  }//fin de foreach de sql


                } catch(PDOException $e) {echo 'Error conectando con la base de datos: ' . $e->getMessage();}




               
            try{
               $registros=0;
                $connection=getConnection();
                $sql=$connection->prepare("SELECT solicitudes.id,fecha,tipo,fecha_creado,estado_pendiente,
                hora_especial, id_punto_especial, nombre_punto_esp
                from solicitudes
                inner join puntos_especiales as p on p.id=solicitudes.id_punto_especial
                where estado_servicio='1' and id_usuario='$id_usuario' and estado_pendiente='1' and tipo='3'
                 order by fecha,hora_especial asc");
                $sql->execute();
              $resultado=$sql->fetchAll();

             foreach($resultado as $row){   
               if($row['fecha']>$ayer){
                
                  $fecha_hora_hasta=$row['fecha'].' '.$row['hora_especial'];
                  $fecha_hora_hasta=strtotime('+60 minute',strtotime($fecha_hora_hasta));
                  $fecha_hora_hasta=date('Y-m-d H:i:s',$fecha_hora_hasta);

                  $fecha_hora=$row['fecha'].' '.$row['hora_especial'];
                  $fecha_uno=strtotime('-1 hour',strtotime($fecha_hora));
                  $fecha_uno=date('Y-m-d H:i:s',$fecha_uno);

                  $fecha_actual=date('Y-m-d H:i:s');

                   if(($fecha_actual > $fecha_uno)&&($fecha_actual < $fecha_hora_hasta)){$visualizable=1;}else{$visualizable=0;}
                    
                     if($registros < 3){

                         $arreglo_proxAbordaje[] = array('id_solicitud'=>$row['id'],'nombre_ruta'=>'Trasl. Especial, a las:'.$row['hora_especial'],
                            'id_ruta'=>'0','fecha'=>$row['fecha'],'tipo'=>'Trasl. Especial', 
                           'hora_inicio'=>$fecha_uno,'hora_fin'=>$fecha_hora_hasta,'visualizable'=>$visualizable,
                           'nombre_punto'=>$row['nombre_punto_esp'], 'direccion'=>'');
                      
                            $registros++;

                       } 


               }//si la fecha es valida

             }//fin de foreach            



               } catch(PDOException $e) {echo 'Error conectando con la base de datos: ' . $e->getMessage();}








                  $app->response->headers->set("Content-type","application/json");
	                $app->response->status(200);
	                $app->response->body(json_encode($arreglo_proxAbordaje));

});










$app->post("/verUnidad/", function() use ($app)
  {

      date_default_timezone_set('America/Managua');
       $arreglo_ubicacion=array();


       $id_usuario=$app->request->post("id_usuario");
       $id_solicitud=$app->request->post("id_solicitud");
       $id_ruta=$app->request->post("id_ruta");
       $fecha_peticion=$app->request->post("fecha");
       $inicio=$app->request->post("hora_inicio");
       $fin=$app->request->post("hora_fin");

       $bandera_status=0;

       $fecha_hoy=date('Y-m-d');



       $fecha_hora_hasta=$fecha_peticion.' '.$fin;
       $fecha_hora_hasta=strtotime('+20 minute',strtotime($fecha_hora_hasta));
       $fecha_hora_hasta=date('Y-m-d H:i:s',$fecha_hora_hasta);
      
       $fecha_hora_desde=$fecha_peticion.' '.$inicio;
       $fecha_hora_desde=strtotime('-1 hour',strtotime($fecha_hora_desde));
       $fecha_hora_desde=date('Y-m-d H:i:s',$fecha_hora_desde);


        $fecha_hora_actual=date('Y-m-d H:i:s');





        //seleccionamos el vehiculo que anda la ruta hoy en programacion


      if(($fecha_peticion==$fecha_hoy)&&($fecha_hora_actual> $fecha_hora_desde)&&($fecha_hora_actual < $fecha_hora_hasta)){


          $id_avl='';
          $placa='';

          $nombre_gps='';
          $placa_gps='';
          $fecha_gps='';
          $evento_gps='';
          $latitud_gps='';
          $longitud_gps='';
          $icono_gps='';
          $speed_gps='';
          $driver_gps='';


        
           try{
                $connection=getConnection();
                  $sql=$connection->prepare("SELECT operacion.id,id_vehiculo,id_avl,placa,fecha_op
                    from operacion
                    inner join vehiculos on vehiculos.id=operacion.id_vehiculo
                    where estado_operacion='1' and fecha_op='$fecha_hoy' and ruta_id='$id_ruta' limit 1");
 
                 $sql->execute();
                 $resultado=$sql->fetchAll();
                 foreach($resultado as $row){
                          $id_avl= $row['id_avl'];
                          $placa= $row['placa'];
                 }


             } catch(PDOException $e) {echo 'Error conectando con la base de datos: ' . $e->getMessage();}

         
              if($id_avl!=''){

                         $bandera_status=1;
                   try{
                      
                      $URLjson="http://ni.disatelgps.com/ws/?api=Vehicles&sitekey=NI&usr=COOSPECTS&pwd=24578&vsearch=".$id_avl;
                      $records=json_decode(file_get_contents($URLjson));
                     
                      if(isset($records[0])){
                          $obj=$records[0];

                          $nombre_gps=$obj->Name; 
                          $placa_gps=$obj->Plate;
                          $fecha_gps=$obj->Date;
                          $evento_gps=$obj->Event;
                          $latitud_gps=$obj->Latitude;
                          $longitud_gps=$obj->Longitude;
                          $icono_gps=$obj->CourseIcon;
                          $speed_gps=$obj->Speed;
                          $driver_gps=$obj->Driver;


                           $arreglo_ubicacion[] = array('bandera_status'=>1 ,'nombre_gps'=>$nombre_gps,'placa_gps'=>$placa_gps,
                            'fecha_gps'=>$fecha_gps,'evento_gps'=>$evento_gps,'latitud_gps'=> $latitud_gps,
                            'longitud_gps'=>$longitud_gps,'icono_gps'=>$icono_gps,'speed_gps'=>$speed_gps,
                            'driver_gps'=>$driver_gps);
                       }
  
                  }catch(Exception $e){echo"error".$e->getMessage;};

                         



              }else{
                      $arreglo_ubicacion[] = array('bandera_status'=>0);
              }//fin si el id es valido


           }else{

                //error al pedir ubiacion de dia diferente

               $arreglo_ubicacion[] = array('bandera_status'=>0);

               }



                  $app->response->headers->set("Content-type","application/json");
                  $app->response->status(200);
                  $app->response->body(json_encode($arreglo_ubicacion));





  });







  
   // metodo ver todos los registros de solcitudes

$app->post("/historialSolicitudes/", function() use ($app)
  {
        date_default_timezone_set('America/Managua');
         $arreglo_historico=array();
         $id_usuario=$app->request->post("id_usuario");

         $diauno= date('Y-m-d', strtotime('-1 day')); 
         $diacinco= date('Y-m-d', strtotime('-5 day')); 
          $hora_actual=date('H:i:s');


      try{
            $connection=getConnection();
              $sql=$connection->prepare("SELECT solicitudes.id,nombre_ruta,fecha,tipo,fecha_creado,
                estado_pendiente,tipo,estado_servicio,id_ruta,hora_inicio,hora_fin,detalle,
                 coalesce(nombre_punto,'vacio') as punto_nombre,direccion 
                from solicitudes
                inner join rutas on rutas.id=solicitudes.id_ruta
                left join puntos on puntos.id=solicitudes.id_punto
                where id_usuario='$id_usuario' and fecha between '$diacinco' and '$diauno'
                 order by fecha asc");

              $sql->execute();
              $resultado=$sql->fetchAll();

             foreach($resultado as $row){

                    if($row['estado_servicio']==1){
                       $status='Procesado';
                    }else{
                      $status="cancelado";
                    }
                   

                    if($row['tipo']==1){
                            $tipo='Trasl. Aeropuerto';
                     }else{
                         $tipo='Transp. Domiliar';
                     }


                       if($row['tipo']!=3){
                         $arreglo_historico[] = array('idhistorico'=>$row['id'],'nombre_ruta'=>$row['nombre_ruta'],
                         'fecha'=>$row['fecha'],'creado'=>$row['fecha_creado'],'tipo'=>$tipo,'estatus'=>$status,
                         'detalle'=>$row['detalle'],'nombre_punto'=>$row['punto_nombre'],'direccion'=>$row['direccion']);
                        }
                  
             }


          }catch(PDOException $e){ echo "Error".$e->getMessage();}




             try{
                 $connection=getConnection();
                 $sql=$connection->prepare("SELECT solicitudes.id,fecha,tipo,fecha_creado,estado_pendiente,
                  hora_especial, id_punto_especial, nombre_punto_esp,estado_servicio,detalle
                  from solicitudes
                  inner join puntos_especiales as p on p.id=solicitudes.id_punto_especial
                  where fecha between '$diacinco' and '$diauno'
                  and id_usuario='$id_usuario' and estado_pendiente='1' and tipo='3'
                  order by fecha asc");

                 $sql->execute();
                 $resultado=$sql->fetchAll();

             foreach($resultado as $row){

                    if($row['estado_servicio']==1){
                       $status='Procesado';
                    }else{
                      $status="cancelado";
                    }

                      $arreglo_historico[] = array('idhistorico'=>$row['id'],'nombre_ruta'=>'Trasl. Especial, a las:'.$row['hora_especial'],
                         'fecha'=>$row['fecha'],'creado'=>$row['fecha_creado'],'tipo'=>'Trasl. Especial','estatus'=>$status,
                         'detalle'=>$row['detalle'],'nombre_punto'=>$row['nombre_punto_esp'],'direccion'=>'');
                    


              }//fin de foreach     
    
             }catch(PDOException $e){ echo "Error".$e->getMessage();}




       $app->response->headers->set("Content-type","application/json");
       $app->response->status(200);
       $app->response->body(json_encode($arreglo_historico));

});















$app->post("/olvideAcceso/", function() use ($app)
{

      $usuario=$app->request->post("usuario");
      $correo="";
      $resultados = array();

    if($usuario!=""){

          $connection=getConnection();
         

           try {

                 $datos = $connection->query("SELECT correo, pwd FROM usuarios_fn where usr='".$usuario."' and activo='1' ");
                 foreach($datos as $row){
                     $correo=$row[0];
                     $pwd_buscado=$row[1];
                   }
             } catch(PDOException $e) {echo 'Error conectando con la base de datos, correos: ' . $e->getMessage();}



           if($correo==""){

             $resultados["estado"] = "error"; 
             $resultados["mensaje"] = "verifique su nombre de usuario"; 
            
           }else{

              //enviaremos la clave

             $resultados["estado"] = "Procesando"; 
             $resultados["mensaje"] = "Acceso enviado a la cuenta:".$correo; 

                   $CopiarA="alinton.gutierrez@grupodisatel.com";
                   $Asunto="Recuperacion contraseña";
                   $Cuerpo="<br><br>Acceso a cuenta de aplicacion movil.";
                   $Cuerpo.="<br><br><strong>usuario:</strong>".$usuario;
                   $Cuerpo.="<br><strong>contraseña:</strong>".$pwd_buscado;
                     $Cuerpo.="<br><strong>Generado a las:</strong>".date('Y-m-d H:i:s');
                   $Cuerpo.="<br><br>Gracias por utilizar nuestra Aplicacion.";
                   $Cuerpo.="<br>Powered by Disatel NI";

                   $Cuerpo.="<br><br>Aviso de confidencialidad:";
                   $Cuerpo.="<br><p> Este mensaje y sus documentos adjuntos, pueden contener informacion privilegiada y/o  
                   confidencial  que  esta dirigida  exclusivamente a su destinatario. Si usted recibe este mensaje y
                   no es el destinatario indicado,por favor, notifiquelo inmediatamente y remita el mensaje original 
                   al correo electronico indicado. Cualquier  copia,  uso  o  distribucion no autorizados de esta 
                   comunicacion queda estrictamente prohibida.</p>";
               
              EnviaCorreo($correo,$CopiarA,$Asunto,$Cuerpo,true);

             //$pwd_buscado;



           }

     }


     $app->response->headers->set("Content-type","application/json");
     $app->response->status(200);
     $app->response->body(json_encode($resultados));

});




  //metodo para editar estado de registro solcitudes
  
  $app->post("/actualizarCuenta/", function() use($app)
  {

     date_default_timezone_set('America/Managua');

     
     $id_usuario=$app->request->post("id_usuario");
     $campo=$app->request->post("campo");
     $nuevo_valor=$app->request->post("nuevo_valor");
    
  
      $respuesta=array();


    try{
           $connection=getConnection();
  
             $stmt = $connection->prepare("UPDATE usuarios_fn SET ".$campo."='".$nuevo_valor."' WHERE id='".$id_usuario."'");
             $rows = $stmt->execute();
          
            if( $rows > 0 ){
              $respuesta[]='Datos Actualizados';
             }

       } catch(PDOException $e){echo "Error".$e->getMessage();} 


          $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($respuesta)); 


      });







function NotificarSolicitud($correo,$usuario,$ruta,$fecha,$detalle_ruta){



                   $CopiarA="alinton.gutierrez@grupodisatel.com";
                   $Asunto="Confirmacion Solicitud Servicio";
                   $Cuerpo="<br><br>Datos de Transporte solicitado.";
                   $Cuerpo.="<br><br><strong>usuario:</strong>".$usuario;
                   $Cuerpo.="<br><strong>Ruta:</strong>".$ruta;
                   $Cuerpo.="<br><strong>Detalle Ruta:</strong>".$detalle_ruta;
                    $Cuerpo.="<br><strong>Fecha Abordaje:</strong>".$fecha;

                     $Cuerpo.="<br><strong>Generado a las:</strong>".date('Y-m-d H:i:s');
                   $Cuerpo.="<br><br>Gracias por utilizar nuestra Aplicacion.";
                   $Cuerpo.="<br>Powered by Disatel NI";

                   $Cuerpo.="<br><br>Aviso de confidencialidad:";
                   $Cuerpo.="<br><p> Este mensaje y sus documentos adjuntos, pueden contener informacion privilegiada y/o  
                   confidencial  que  esta dirigida  exclusivamente a su destinatario. Si usted recibe este mensaje y
                   no es el destinatario indicado,por favor, notifiquelo inmediatamente y remita el mensaje original 
                   al correo electronico indicado. Cualquier  copia,  uso  o  distribucion no autorizados de esta 
                   comunicacion queda estrictamente prohibida.</p>";
               
              EnviaCorreo($correo,$CopiarA,$Asunto,$Cuerpo,true);

             //$pwd_buscado;




}







//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------

//------------------------------>metodos de mapas de vista web-------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------









    $app->post("/listarRutasOperacion/", function() use ($app)
  {
  
    date_default_timezone_set('America/Managua');
    $fecha_actual=date('Y-m-d');

    $arreglo=array();

      try{
        $connection=getConnection();


         $sql=$connection->prepare("SELECT o.id, id_vehiculo,unidad,placa,id_avl, ruta_id,nombre_ruta,hora_inicio,hora_fin,tipo_ruta
          from operacion as o 
          inner join rutas  as r on  r.id=o.ruta_id
          inner join vehiculos as v on v.id=o.id_vehiculo
          where fecha_op='$fecha_actual' and  estado_operacion='1'");

         $sql->execute();
         $resultado=$sql->fetchAll();

             foreach($resultado as $row){
                  $arreglo[] = array('id_vehiculo'=>$row['id_vehiculo'],'unidad'=>$row['unidad'],'placa'=>$row['placa'],
                    'id_avl'=>$row['id_avl'],'ruta_id'=>$row['ruta_id'],'nombre_ruta'=>utf8_encode($row['nombre_ruta']),
                    'hora_inicio'=>$row['hora_inicio'], 'hora_fin'=>$row['hora_fin']);
               }
  

         
         }catch(PDOException $e){ echo "Error".$e->getMessage();}  


        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($arreglo));
        


       
  });





    $app->post("/listarAbordaje/", function() use ($app)
  {
  
    date_default_timezone_set('America/Managua');
    $fecha_actual=date('Y-m-d');


     $ruta_id=$app->request->post("ruta_id");
     $ruta_desde=$app->request->post("ruta_desde");
     $ruta_hasta=$app->request->post("ruta_hasta");

    $arreglo=array();

      try{
        $connection=getConnection();


         $sql=$connection->prepare("SELECT a.id,usuario_id,vehiculo_abo,ruta_abo,fecha,
               hora,latitud,longitud, fin_viaje, usr,nombre,apellido
              from abordajes as a 
              inner join usuarios_fn as u on u.id=a.usuario_id
               where fecha='$fecha_actual' and ruta_abo='$ruta_id' and hora between '$ruta_desde' and '$ruta_hasta' ");

         $sql->execute();
         $resultado=$sql->fetchAll();

             foreach($resultado as $row){

                  $arreglo[] = array('id'=>$row['id'],'usuario_id'=>$row['usuario_id'],'vehiculo_abo'=>$row['vehiculo_abo'],
                    'ruta_abo'=>$row['ruta_abo'],'fecha'=>$row['fecha'],'hora'=>$row['hora'],'latitud'=>$row['latitud'],
                    'longitud'=>$row['longitud'], 'fin_viaje'=>$row['fin_viaje'], 'usr'=>$row['usr'],'nombre'=>$row['nombre'],
                    'apellido'=>$row['apellido']);
               }
  

         
         }catch(PDOException $e){ echo "Error".$e->getMessage();}  


        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($arreglo));
        


       
  });







$app->post("/AutoUbicar/", function() use ($app)
  {

      date_default_timezone_set('America/Managua');
      
       $arreglo_ubicacion=array();

       $id_avl=$app->request->post("id_avl");

       $fecha_hoy=date('Y-m-d');



        //seleccionamos el vehiculo que anda la ruta hoy en programacion


      if($id_avl!=''){


          $id_avl='';
          $placa='';

          $nombre_gps='';
          $placa_gps='';
          $fecha_gps='';
          $evento_gps='';
          $latitud_gps='';
          $longitud_gps='';
          $icono_gps='';
          $speed_gps='';
          $driver_gps='';
           $address_gps='';


        

                         $bandera_status=1;
                   try{
                      
                      $URLjson="http://ni.disatelgps.com/ws/?api=Vehicles&sitekey=NI&usr=COOSPECTS&pwd=24578&vsearch=".$id_avl;
                      $records=json_decode(file_get_contents($URLjson));
                     
                      if(isset($records[0])){
                          $obj=$records[0];

                          $nombre_gps=$obj->Name; 
                          $placa_gps=$obj->Plate;
                          $fecha_gps=$obj->Date;
                          $evento_gps=$obj->Event;
                          $latitud_gps=$obj->Latitude;
                          $longitud_gps=$obj->Longitude;
                          $icono_gps=$obj->CourseIcon;
                          $speed_gps=$obj->Speed;
                          $driver_gps=$obj->Driver;
                          $address_gps=$obj->Address;


                           $arreglo_ubicacion[] = array('bandera_status'=>1 ,'nombre_gps'=>$nombre_gps,'placa_gps'=>$placa_gps,
                            'fecha_gps'=>$fecha_gps,'evento_gps'=>$evento_gps,'latitud_gps'=> $latitud_gps,
                            'longitud_gps'=>$longitud_gps,'icono_gps'=>$icono_gps,'speed_gps'=>$speed_gps,
                            'driver_gps'=>$driver_gps,'address_gps'=>$address_gps);
                       }
  
                  }catch(Exception $e){echo"error".$e->getMessage;};

                         



             

           }else{

                //error al pedir ubiacion de dia diferente

               $arreglo_ubicacion[] = array('bandera_status'=>0);

               }



                  $app->response->headers->set("Content-type","application/json");
                  $app->response->status(200);
                  $app->response->body(json_encode($arreglo_ubicacion));





  });








//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------

//------------------------------>metodos de operacion especial-------------------------------------------------------------

//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------






$app->post("/listarPuntosEspeciales/", function() use ($app)
  {
  
    $arreglo=array();

      try{
        $connection=getConnection();


         $sql=$connection->prepare("SELECT id,nombre_punto_esp from puntos_especiales where estado_punto_esp='1'");
         $sql->execute();
         $resultado=$sql->fetchAll();

             foreach($resultado as $row){
                  $arreglo[] = array('idpunto'=>$row['id'],'nombre_punto_esp'=>utf8_encode($row['nombre_punto_esp']));
               }
  

         
         }catch(PDOException $e){ echo "Error".$e->getMessage();}  


        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($arreglo));
        


       
  });







  //metodo de insertar solicitudes usando post
  
  $app->post("/registrarSolicitudEspecial/", function() use($app)
  {
     
     date_default_timezone_set('America/Managua');

     $ayer= date('Y-m-d', strtotime('-1 day')); 
     $estado=array();

       $id_usuario=$app->request->post("id_usuario");
       $id_ruta='';
       $fecha=$app->request->post("fecha");
       $fecha_desde=$app->request->post("fecha_desde");
       $fecha_hasta=$app->request->post("fecha_hasta"); 
       $tipo=$app->request->post("tipo");
       $frecuencia=$app->request->post("frecuencia");

       //nuevos datos para correo
       $correo=$app->request->post("correo");
       $usuario=$app->request->post("nombre_usr");

       $id_punto_especial=$app->request->post("id_punto_especial");
       $nombre_punto_especial=$app->request->post("nombre_punto_especial");
       $hora_especial=$app->request->post("hora_especial");

       $ruta='Solicitud Especial';
       $detalle_ruta='punto:'. $nombre_punto_especial;

       $id_punto='';
       $direccion='';
 
        
    
        

      

          //registro una vez  
         if($frecuencia=="unavez"){

          if($fecha >$ayer){

              $fecha_hora=$fecha.' '.$hora_especial;
              $fecha_dos=strtotime('-2 hour',strtotime($fecha_hora));
              $fecha_dos=date('Y-m-d H:i:s',$fecha_dos);
              $fecha_actual=date('Y-m-d H:i:s');

              if($fecha_actual < $fecha_dos){


                //verificamos duplicados
                $numero_registro=0;

                  try {
                       $connection=getConnection();
                       $datos = $connection->query("SELECT count(*) FROM solicitudes where id_usuario='".$id_usuario."'
                            and tipo='".$tipo."' and fecha='".$fecha."' and id_punto_especial='".$id_punto_especial."'
                             and  estado_servicio='1' ");
                      foreach($datos as $row){
                       $numero_registro=$row[0];
                      }
                    
                     }catch(PDOException $e) {echo 'Error conectando con la base de datos, insert: ' . $e->getMessage();}


               if($numero_registro<1){



               try{
     
                  $connection=getConnection();
                   $stmt = $connection->prepare('INSERT INTO solicitudes( fecha, id_usuario, id_ruta, tipo,
                    id_punto, direccion, id_punto_especial, hora_especial) 
                    VALUES (:fecha, :id_usuario, :id_ruta, :tipo, :id_punto, :direccion, :id_punto_especial, :hora_especial)');

                   $rows=$stmt->execute(array(':fecha'=>$fecha ,':id_usuario' =>$id_usuario,
                    ':id_ruta'=>$id_ruta, ':tipo'=>$tipo, ':id_punto'=>$id_punto, ':direccion'=>$direccion,
                    ':id_punto_especial'=>$id_punto_especial, ':hora_especial'=>$hora_especial));

             
                    if($rows==1){
                        $estado[]="Solicitud registrada";

                       //notificar por correo
                       NotificarSolicitud($correo,$usuario,$ruta,$fecha,$detalle_ruta);

                      }else{
                       $estado[]="Error sql";
                       }

                      
                
                     }catch(PDOException $e){echo "Error insertando".$e->getMessage();}

               }else{

                   $estado[]="Error: registro duplicado";

               }


                  }else{
                    $estado[]="Error: debes solicilitar transporte 2 hrs antes en dia actual".$fecha_dos;

                 }

           }else{
                $estado[]="Error en campo fecha";
           }

     
          }






           if($frecuencia=="varias"){




             if(($fecha_desde<$fecha_hasta)&&($fecha_desde >$ayer)){


                   $fecha_hora=$fecha_desde.' '.$hora_especial;
                   $fecha_dos=strtotime('-1 hour',strtotime($fecha_hora));
                   $fecha_dos=date('Y-m-d H:i:s',$fecha_dos);
                   $fecha_actual=date('Y-m-d H:i:s');


                   $arreglo_dias=array();   
                   $arreglo_dias[]=$fecha_desde;



              if($fecha_actual < $fecha_dos){


                   
                 if($fecha_desde < $fecha_hasta){
                    $fecha_dinamica=$fecha_desde;
                    while($fecha_dinamica!=$fecha_hasta){
                     $fecha_dinamica=date('Y-m-d', strtotime($fecha_dinamica.'+1 day'));
                     $arreglo_dias[]=$fecha_dinamica;
                   }
                   }


                  if($fecha_desde==$fecha_hasta){
                     $arreglo_dias[]=$fecha_desde;  
                    }



                        //verificamos duplicados
                      $numero_registro=0;

                      try {
                           $connection=getConnection();
                        $datos = $connection->query("SELECT count(*) FROM solicitudes where id_usuario='".$id_usuario."'
                             and tipo='".$tipo."' and fecha between '".$fecha_desde."' and '".$fecha_hasta."' 
                             and id_punto_especial='".$id_punto_especial."' and estado_servicio='1' ");
                      foreach($datos as $row){
                       $numero_registro=$row[0];
                      }
                    
                     } catch(PDOException $e) {echo 'Error conectando con la base de datos, login: ' . $e->getMessage();}



                     $bandera_insert=false;


                     if($numero_registro<1){


                     if(count($arreglo_dias)<16){
                     

                    foreach($arreglo_dias as $fecha){

                         try{
     
                         $connection=getConnection();
                           $stmt = $connection->prepare('INSERT INTO solicitudes( fecha, id_usuario, id_ruta, tipo,
                            id_punto,direccion,id_punto_especial, hora_especial) 
                            VALUES (:fecha, :id_usuario, :id_ruta, :tipo, :id_punto, :direccion, :id_punto_especial, :hora_especial)');

                          $rows=$stmt->execute(array(':fecha'=>$fecha ,':id_usuario' =>$id_usuario,
                          ':id_ruta'=>$id_ruta, ':tipo'=>$tipo, ':id_punto'=> $id_punto, ':direccion'=>$direccion,
                           ':id_punto_especial'=>$id_punto_especial, ':hora_especial'=>$hora_especial));
             
                           if($rows==1){
                             $estado[]="Solicitud registrada";

                            $bandera_insert=true;

                              }else{
                                $estado[]="Error sql";
                              }
                
                          }catch(PDOException $e){echo "Error insertando".$e->getMessage();}

                      }//fin de foreach de fechas



                    }else{

                      $estado[]="Error: no se permite mas de 15 dias";
                    }
                 
                     }else{
                         $estado[]="Error: registro duplicado";
                     }


                   }else{
                     $estado[]="Error: debes solicilitar transporte 2 hrs antes en dia actual";

                    }





                          if($bandera_insert==true){

                            //notificar por correo
                             $textfecha='desde:'.$fecha_desde.', hasta:'.$fecha_hasta;
                             NotificarSolicitud($correo,$usuario,$ruta,$textfecha,$detalle_ruta);

                          }
                           



             }else{

              $estado[]="Error fecha incorrecta";
             }


            }//fin de varias fechas


       
        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($estado)); 

    
    
  });

	
	




  
   // metodo ver todos los registros de solcitudes

$app->post("/listaSolicitudes_esp/", function() use ($app)
  {
        date_default_timezone_set('America/Managua');
        $arreglo_historico=array();
         $id_usuario=$app->request->post("id_usuario");

            $hoy= date('Y-m-d'); 
            $diacinco= date('Y-m-d', strtotime('-5 day')); 
            $hora_actual=date('H:i:s');


      try{
            $connection=getConnection();
              $sql=$connection->prepare("SELECT solicitudes.id,fecha,tipo,fecha_creado,estado_pendiente,
              hora_especial, id_punto_especial, nombre_punto_esp
                from solicitudes
                inner join puntos_especiales as p on p.id=solicitudes.id_punto_especial
                where estado_servicio='1' and id_usuario='$id_usuario' and estado_pendiente='1' and tipo='3'
                 order by fecha asc");
              $sql->execute();
              $resultado=$sql->fetchAll();

             foreach($resultado as $row){



                  $fecha_hora=$row['fecha'].' '.$row['hora_especial'];

                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $fecha_actual=date('Y-m-d H:i:s');

                   if($fecha_actual < $fecha_cuatro){
                   // echo'<br> si puedes borrar';
                     $opcion_borrado=1;
                  }else{
                    //echo'<br> no puedes borrar';
                     $opcion_borrado=0;
                  }




                   $pendiente=$row['estado_pendiente'];

                  if($pendiente==1){
                      $status='Agendado';
                  }else{
                    $status='Procesado';
                  }
                   

                   if($row['fecha']<date('Y-m-d')){
                      $status='Procesado';
                    }


                 if($status=='Agendado'){
                       $arreglo_historico[] = array('idhistorico'=>$row['id'],'fecha'=>$row['fecha'],
                        'hora_especial'=>$row['hora_especial'],'creado'=>$row['fecha_creado'],
                        'tipo'=>$row['tipo'],'estado_pendiente'=>$row['estado_pendiente'],
                        'opcion_borrado'=>$opcion_borrado,'txstatus'=>$status,
                        'id_punto_especial'=>$row['id_punto_especial'],'nombre_punto_esp'=>$row['nombre_punto_esp']);
                  }
             }


          }catch(PDOException $e){ echo "Error".$e->getMessage();}


       $app->response->headers->set("Content-type","application/json");
       $app->response->status(200);
       $app->response->body(json_encode($arreglo_historico));

});
  







  //metodo para editar estado de registro solcitudes
  
  $app->post("/EditarPeticion_Esp/", function() use($app)
  {

     date_default_timezone_set('America/Managua');
     $ayer= date('Y-m-d', strtotime('-1 day')); 
     
     $bandera_actualizado=false;
     
      $usuario=$app->request->post("usuario");
      $id_update=$app->request->post("id_update");

      $fecha_antes=$app->request->post("fecha_antes");
      $hora_antes=$app->request->post("hora_antes");

      $fecha_update=$app->request->post("fecha_update");
      $hora_update=$app->request->post("hora_update");

      $id_punto_especial=$app->request->post("id_punto_especial");
      $nombre_punto_especial=$app->request->post("nombre_punto_especial");
      $correo_enviar=$app->request->post("correo");

    

    
      $actualizar=0;
      $estado_update=array();
      $detalle='Actualizado por:'.$usuario.', a las:'.date('Y-m-d H:i:s');
    


      //selecionar el dia y hora, verificando que sea posible actualizar

         

          
            if(($fecha_update > $ayer) && ($hora_update!='')){


                  $fecha_hora=$fecha_antes.' '.$hora_antes;
                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $nueva_fecha_hora=$fecha_update.' '.$hora_update;
                  $nueva_fecha_hora=strtotime('-3 hour',strtotime($nueva_fecha_hora));
                  $nueva_fecha_hora=date('Y-m-d H:i:s',$nueva_fecha_hora);


                  $fecha_actual=date('Y-m-d H:i:s');

                   //actualziar peticion, con fecha valida mayor ayer

                   if(($fecha_actual < $fecha_cuatro)&&($fecha_actual < $nueva_fecha_hora)){
                   // echo'<br> si puedes borrar';
                     
                      
                  try{
                       $connection=getConnection();

                       $stmt = $connection->prepare("UPDATE solicitudes SET fecha=:fecha,
                        hora_especial=:hora_especial, id_punto_especial=:id_punto_especial
                        WHERE id=:id");

                       $rows = $stmt->execute( array(':fecha'=>$fecha_update,':hora_especial'=>$hora_update,
                        ':id_punto_especial'=>$id_punto_especial,':id'=> $id_update));
            
                    if( $rows > 0 ){
                       $estado_update[]='Peticion Actualizada';
                         $bandera_actualizado=true;
                    }

                     } catch(PDOException $e){echo "Error".$e->getMessage();} 

                     


                  }else{
                    //echo'<br> no puedes borrar';
                    $estado_update[]='Error ya no puedes Actualizar';
                    
                  }



                 

                 //si a sido actualizado. confirmaremos via correo

                  if(($bandera_actualizado==true)&&($correo_enviar!="")){


                   $CopiarA="alinton.gutierrez@grupodisatel.com";
                   $Asunto="Actualizacion de Abordaje Realizada";
                   $Cuerpo="<br><br><strong>Datos</strong>";
                   $Cuerpo="<br><strong>usuario:</strong>".$usuario;
                   $Cuerpo.="<br><strong>Ruta:</strong>".'Solicitud Especial:punto:'. $nombre_punto_especial;
                   $Cuerpo.="<br><strong>Fecha:</strong>".$fecha_update;
                   $Cuerpo.="<br><strong>Generado a las:</strong>".date('Y-m-d H:i:s');
                   $Cuerpo.="<br><br>Gracias por utilizar nuestra Aplicacion.";
                   $Cuerpo.="<br>Powered by Disatel NI";

                   $Cuerpo.="<br><br>Aviso de confidencialidad:";
                   $Cuerpo.="<br><p> Este mensaje y sus documentos adjuntos, pueden contener informacion privilegiada y/o  
                   confidencial  que  esta dirigida  exclusivamente a su destinatario. Si usted recibe este mensaje y
                   no es el destinatario indicado,por favor, notifiquelo inmediatamente y remita el mensaje original 
                   al correo electronico indicado. Cualquier  copia,  uso  o  distribucion no autorizados de esta 
                   comunicacion queda estrictamente prohibida.</p>";
               
                    EnviaCorreo($correo_enviar,$CopiarA,$Asunto,$Cuerpo,true);



                 }





            }//fin si tiene datos validos
                  



        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($estado_update)); 


  });









      
  //metodo para editar estado de registro solcitudes
  
  $app->post("/cancelarPeticion_Esp/", function() use($app)
  {
       $bandera_actualizado=false;
       date_default_timezone_set('America/Managua');

     
     $usuario=$app->request->post("usuario");
     $id_historico=$app->request->post("id_historico");
     $correo_enviar=$app->request->post("correo");

     $fecha_abordaje=$app->request->post("fecha_abordaje");
      $hora_abordaje=$app->request->post("hora_abordaje");



    
      $desactivar=0;
      $estado_update=array();
      $detalle='cancelado por:'.$usuario.', a las:'.date('Y-m-d H:i:s');
      $fecha_solicitado='';
      $hora_inicio_ruta='';
      $nombre_ruta='';
      $detalle_ruta='';


      //selecionar el dia y hora, verificando que sea posible cancelar la peticion

         

            if(($fecha_abordaje!="") && ($hora_abordaje!='')){


                 $fecha_hora=$fecha_abordaje.' '.$hora_abordaje;

                  $fecha_cuatro=strtotime('-3 hour',strtotime($fecha_hora));
                  $fecha_cuatro=date('Y-m-d H:i:s',$fecha_cuatro);


                  $fecha_actual=date('Y-m-d H:i:s');

                   if($fecha_actual < $fecha_cuatro){
                   // echo'<br> si puedes borrar';
                     
                      
                  try{
                   $connection=getConnection();
                   $stmt = $connection->prepare("UPDATE solicitudes SET estado_servicio=:estado,detalle=:detalle WHERE id=:id");
                   $rows = $stmt->execute( array(':estado'=>$desactivar,':detalle'=>$detalle,':id'=>$id_historico));
            
                    if( $rows > 0 ){
                       $estado_update[]='Peticion Cancelada';
                       $bandera_actualizado=true;
                    }

                     } catch(PDOException $e){echo "Error".$e->getMessage();} 

                     


                  }else{
                    //echo'<br> no puedes borrar';
                    $estado_update[]='Error ya no puede eliminarla';
                    
                  }



                    //si a sido actualizado. confirmaremos via correo

                  if(($bandera_actualizado==true)&&($correo_enviar!="")){


                   $CopiarA="alinton.gutierrez@grupodisatel.com";
                   $Asunto="Cancelacion de Abordaje Realizada";
                   $Cuerpo="<br><br><strong>Datos</strong>";
                   $Cuerpo="<br><strong>usuario:</strong>".$usuario;
                   $Cuerpo.="<br><strong>Ruta Abordar:</strong>".$nombre_ruta;
                   $Cuerpo.="<br><strong>Detalle Ruta:</strong>".$detalle_ruta;
                   $Cuerpo.="<br><strong>Fecha Abordaje:</strong>".$fecha_solicitado;
                   $Cuerpo.="<br><strong>Generado a las:</strong>".date('Y-m-d H:i:s');
                   $Cuerpo.="<br><br>Gracias por utilizar nuestra Aplicacion.";
                   $Cuerpo.="<br>Powered by Disatel NI";

                   $Cuerpo.="<br><br>Aviso de confidencialidad:";
                   $Cuerpo.="<br><p> Este mensaje y sus documentos adjuntos, pueden contener informacion privilegiada y/o  
                   confidencial  que  esta dirigida  exclusivamente a su destinatario. Si usted recibe este mensaje y
                   no es el destinatario indicado,por favor, notifiquelo inmediatamente y remita el mensaje original 
                   al correo electronico indicado. Cualquier  copia,  uso  o  distribucion no autorizados de esta 
                   comunicacion queda estrictamente prohibida.</p>";
               
                    EnviaCorreo($correo_enviar,$CopiarA,$Asunto,$Cuerpo,true);



                 }

                   





            }//fin si tiene datos validos
                  



        $app->response->headers->set("Content-type","application/json");
        $app->response->status(200);
        $app->response->body(json_encode($estado_update)); 


      });





















	
	 ?>